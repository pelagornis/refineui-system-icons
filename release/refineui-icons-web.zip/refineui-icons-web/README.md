# RefineUI System Icons - WEB

This package contains RefineUI System Icons files for web platform.

## Included Files
- web/
- fonts/

## Installation and Usage
For detailed information, see the main README.md.

## License
MIT License
