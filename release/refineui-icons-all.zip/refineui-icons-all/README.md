# RefineUI System Icons - ALL

This package contains RefineUI System Icons files for all platform.

## Included Files
- web/
- fonts/
- android/
- ios/
- flutter/

## Installation and Usage
For detailed information, see the main README.md.

## License
MIT License
