# RefineUI System Icons - FLUTTER

This package contains RefineUI System Icons files for flutter platform.

## Included Files
- flutter/

## Installation and Usage
For detailed information, see the main README.md.

## License
MIT License
